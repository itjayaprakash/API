import React from 'react';


export default class Dashboard extends React.Component {
    render() {
        return (
            <div>
                <h2>Dashboard Page content</h2>
                <div>
                    </div>
            </div>
        )
    }
}