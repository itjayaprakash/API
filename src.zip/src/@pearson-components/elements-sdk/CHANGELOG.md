<a name="2.1.3"></a>
## [2.1.3](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v2.1.2...v2.1.3) (2020-03-12)



<a name="2.1.2"></a>
## [2.1.2](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v2.1.1...v2.1.2) (2019-12-10)



<a name="2.1.1"></a>
## [2.1.1](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v2.1.0...v2.1.1) (2019-12-10)



<a name="2.1.0"></a>
# [2.1.0](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v2.7.0...v2.1.0) (2019-12-10)



<a name="2.7.0"></a>
# [2.7.0](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v2.0.6...v2.7.0) (2019-12-10)



<a name="2.0.6"></a>
## [2.0.6](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v2.0.5...v2.0.6) (2019-02-01)



<a name="2.0.5"></a>
## [2.0.5](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v2.0.3...v2.0.5) (2019-02-01)



<a name="2.0.3"></a>
## [2.0.3](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v2.0.2...v2.0.3) (2018-12-05)



<a name="2.0.2"></a>
## [2.0.2](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/2.0.2...v2.0.2) (2018-10-08)



<a name="2.0.0"></a>
# [2.0.0](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.15.5...v2.0.0) (2018-09-24)



<a name="1.15.5"></a>
## [1.15.5](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.15.4...v1.15.5) (2018-08-27)



<a name="1.15.4"></a>
## [1.15.4](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.15.3...v1.15.4) (2018-08-27)


### Bug Fixes

* add in proptypes to the dropdown item ([583bd83](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/583bd83))



<a name="1.15.3"></a>
## [1.15.3](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.15.2...v1.15.3) (2018-08-17)



<a name="1.15.2"></a>
## [1.15.2](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.15.1...v1.15.2) (2018-08-15)



<a name="1.15.1"></a>
## [1.15.1](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.15.0...v1.15.1) (2018-08-10)



<a name="1.15.0"></a>
# [1.15.0](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.14.1...v1.15.0) (2018-08-02)



<a name="1.14.1"></a>
## [1.14.1](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.14.0...v1.14.1) (2018-07-30)



<a name="1.14.0"></a>
# [1.14.0](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.13.0...v1.14.0) (2018-07-10)



<a name="1.13.0"></a>
# [1.13.0](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.12.4...v1.13.0) (2018-06-25)



<a name="1.12.4"></a>
## [1.12.4](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.12.3...v1.12.4) (2018-06-07)



<a name="1.12.3"></a>
## [1.12.3](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.12.2...v1.12.3) (2018-05-31)


### Bug Fixes

* type=button back on imageButton case ([aba28fc](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/aba28fc))



<a name="1.12.2"></a>
## [1.12.2](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.12.1...v1.12.2) (2018-05-24)



<a name="1.12.1"></a>
## [1.12.1](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.12.0...v1.12.1) (2018-05-23)


### Bug Fixes

* **dropdown:** add keys to drop down menu items ([83c4ebf](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/83c4ebf))



<a name="1.12.0"></a>
# [1.12.0](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.11.3...v1.12.0) (2018-05-07)


### Features

* Add in value prop for text inputs ([d8c0e34](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/d8c0e34))



<a name="1.11.3"></a>
## [1.11.3](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.11.2...v1.11.3) (2018-04-26)



<a name="1.11.2"></a>
## [1.11.2](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.11.1...v1.11.2) (2018-04-26)


### Bug Fixes

* callback for tabs on activated, add in key passing in callback ([54e59ad](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/54e59ad))



<a name="1.11.1"></a>
## [1.11.1](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.11.0...v1.11.1) (2018-04-25)



<a name="1.11.0"></a>
# [1.11.0](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.10.7...v1.11.0) (2018-04-24)



<a name="1.10.7"></a>
## [1.10.7](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.10.6...v1.10.7) (2018-04-23)



<a name="1.10.6"></a>
## [1.10.6](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.10.2...v1.10.6) (2018-04-16)


### Bug Fixes

* Correct default values for 24hr clock in Timepicker ([c305c55](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/c305c55))
* Properly stop event bubbling on enter & space || Move Cal ref from container to child ([52c3a92](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/52c3a92))



<a name="1.10.2"></a>
## [1.10.2](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.10.1...v1.10.2) (2018-03-27)


### Bug Fixes

* Add additional keyboard functionality ([18c58d9](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/18c58d9))



<a name="1.10.1"></a>
## [1.10.1](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.10.0...v1.10.1) (2018-03-07)


### Bug Fixes

* Clear Footer key warning ([a05c703](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/a05c703))



<a name="1.10.0"></a>
# [1.10.0](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.9.6...v1.10.0) (2018-03-07)



<a name="1.9.6"></a>
## [1.9.6](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.9.5...v1.9.6) (2018-03-06)


### Features

* Add sortable icon ([7127ce1](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/7127ce1))



<a name="1.9.5"></a>
## [1.9.5](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.9.4...v1.9.5) (2018-03-06)



<a name="1.9.4"></a>
## [1.9.4](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.9.3...v1.9.4) (2018-02-20)


### Bug Fixes

* from compounds - prevent scroll when not needed and handle non component children ([6c0fe55](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/6c0fe55))
* Provide unique cn's to StaticAlert ([e40f451](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/e40f451))



<a name="1.9.3"></a>
## [1.9.3](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.9.2...v1.9.3) (2018-02-16)


### Bug Fixes

* multiline text to 3px ([d6d778e](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/d6d778e))
* Removing NodeJs 4 and adding NodeJs 8 ([ef77cc3](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/ef77cc3))
* Starts selectedIndex check at -1 so only valid children will get the selectedIndex value; undefined and other values are sometimes passed in to children as we build up the structure ([3aae5de](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/3aae5de))



<a name="1.9.2"></a>
## [1.9.2](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.9.1...v1.9.2) (2018-02-07)


### Bug Fixes

* Cal unit test ([66811e7](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/66811e7))



<a name="1.9.1"></a>
## [1.9.1](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.9.0...v1.9.1) (2018-01-25)


### Bug Fixes

* Change to Calendar unit test ([81b9a0b](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/81b9a0b))



<a name="1.9.0"></a>
# [1.9.0](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.8.0...v1.9.0) (2018-01-22)


### Bug Fixes

* DES-895, progress bar spacing; also changed label tag to output tag (GLP) ([83be336](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/83be336))
* DES-900, switched button and text around so that close button reads out last ([f8bc279](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/f8bc279))
* issue [#232](https://github.com/Pearson-Higher-Ed/elements-sdk/issues/232) by Dinuka ([b9d571b](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/b9d571b))



<a name="1.8.0"></a>
# [1.8.0](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.7.1...v1.8.0) (2018-01-12)


### Bug Fixes

* Align Calendar's unit tests with Compounds fix. ([1933bd7](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/1933bd7))
* fix package-lock.json file for security vulnerability ([a8194e3](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/a8194e3))



<a name="1.7.1"></a>
## [1.7.1](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.7.0...v1.7.1) (2017-12-20)


### Bug Fixes

* **typeography:** point font URLs to unpkg.com ([7c1c4c2](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/7c1c4c2))


### Features

* **icons:** add breadcrumb icon ([3a2c0e4](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/3a2c0e4))



<a name="1.7.0"></a>
# [1.7.0](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.6.1...v1.7.0) (2017-12-12)


### Bug Fixes

* remove react >15.4 unit test tool movement warnings ([f4a2cea](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/f4a2cea))
* Update Footer copyrightText ([e2e0573](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/e2e0573))



<a name="1.6.1"></a>
## [1.6.1](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.6.0...v1.6.1) (2017-12-06)


### Bug Fixes

* Webpack naming ([0259cc5](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/0259cc5))



<a name="1.6.0"></a>
# [1.6.0](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.5.3...v1.6.0) (2017-12-06)



<a name="1.5.3"></a>
## [1.5.3](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.5.2...v1.5.3) (2017-11-29)


### Bug Fixes

* Routing for gh-pages ([1c31875](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/1c31875))
* Routing for gh-pages ([8bf3774](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/8bf3774))


### Features

* gh-pages script ([85fc22b](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/85fc22b))
* gh-pages script ([2691b2f](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/2691b2f))



<a name="1.5.2"></a>
## [1.5.2](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.5.1...v1.5.2) (2017-11-22)


### Bug Fixes

* babel-runtime ([002f7c8](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/002f7c8))
* expose methods and allow client-side validation ([b2a3460](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/b2a3460))
* remove is_valid_number (too strict) ([d6ad2bf](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/d6ad2bf))



<a name="1.5.1"></a>
## [1.5.1](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.5.0...v1.5.1) (2017-11-21)


### Bug Fixes

* Dropdown button color & setup new Header routes ([caeef09](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/caeef09))



<a name="1.5.0"></a>
# [1.5.0](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.4.3...v1.5.0) (2017-11-17)


### Features

* **PhoneNumber:** Create Phone Number input component ([b4fa6ac](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/b4fa6ac))



<a name="1.4.3"></a>
## [1.4.3](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.4.2...v1.4.3) (2017-11-14)



<a name="1.4.2"></a>
## [1.4.2](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.4.1...v1.4.2) (2017-11-13)


### Features

* Sonar setup ([03c7893](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/03c7893))



<a name="1.4.1"></a>
## [1.4.1](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.4.0...v1.4.1) (2017-11-07)



<a name="1.4.0"></a>
# [1.4.0](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.3.2...v1.4.0) (2017-11-03)



<a name="1.3.2"></a>
## [1.3.2](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.3.1...v1.3.2) (2017-10-31)



<a name="1.3.1"></a>
## [1.3.1](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.2.3...v1.3.1) (2017-10-31)


### Bug Fixes

* color hex corrected ([b8f3a83](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/b8f3a83))



<a name="1.2.3"></a>
## [1.2.3](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.2.2...v1.2.3) (2017-10-19)



<a name="1.2.2"></a>
## [1.2.2](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.2.1...v1.2.2) (2017-10-18)


### Bug Fixes

* allow for dd/mm/yyyy formats in date picker ([4d167ad](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/4d167ad))
* left console.log in (insufficient coffee) ([ff32e6e](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/ff32e6e))
* putting moment dependency back (out of scope for this issue). ([ba4e90b](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/ba4e90b))
* syntax error and remove moment dependency. ([b1b2e6d](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/b1b2e6d))



<a name="1.2.1"></a>
## [1.2.1](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.2.0...v1.2.1) (2017-10-17)



<a name="1.2.0"></a>
# [1.2.0](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.1.1...v1.2.0) (2017-10-17)



<a name="1.1.1"></a>
## [1.1.1](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.1.0...v1.1.1) (2017-10-16)



<a name="1.1.0"></a>
# [1.1.0](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.0.6...v1.1.0) (2017-10-10)



<a name="1.0.6"></a>
## [1.0.6](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.0.5...v1.0.6) (2017-10-03)


### Bug Fixes

* move display none to hidden class in responsive utilities ([ec6d938](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/ec6d938))



<a name="1.0.5"></a>
## [1.0.5](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.0.4...v1.0.5) (2017-09-21)



<a name="1.0.4"></a>
## [1.0.4](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v1.0.0...v1.0.4) (2017-09-21)


### Bug Fixes

* Add npmignore ([6175f0f](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/6175f0f))



<a name="1.0.0"></a>
# [1.0.0](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v0.1.1...v1.0.0) (2017-09-20)



<a name="0.1.1"></a>
## [0.1.1](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/v0.1.0...v0.1.1) (2017-09-20)



<a name="0.1.0"></a>
# [0.1.0](https://github.com/Pearson-Higher-Ed/elements-sdk/compare/1fc70d4...v0.1.0) (2017-09-20)


### Bug Fixes

* remove elements dependency ([1fc70d4](https://github.com/Pearson-Higher-Ed/elements-sdk/commit/1fc70d4))



