import React from "react";
import { BrowserRouter, Router, Route, NavLink, Switch, Redirect, Link } from 'react-router-dom';
import history from "./history";
import Home from './home';
import About from './about';
import Security from './Security';
import logo from './cisco-logo-2007.gif';
import './App.css';
import store, { COUNTER_INCREMENT, COUNTER_DECREMENT } from './Store';

import Tabs from 'react-responsive-tabs';
// IMPORTANT you need to include the default styles
import 'react-responsive-tabs/styles.css';

const presidents = [
    
  
  { name: 'TheodoreRooseveltsdsdssajhghjg', biography: '' },

  { name: 'MONITOR', biography: <Home/> },

  { name: 'WLAN', biography: <Security/> },

  { name: 'CONTROLLER', biography: <Home/>  },

  { name: 'WIRELESS', biography: <Home/> },

  { name: 'SECURITY', biography: <Security/>},

  { name: 'MANAGEMENT', biography: '...' },

  { name: 'COMMANDS', biography: '...' },

  { name: 'HELP', biography: '...' },

  { name: 'FEEDBACK', biography: '...' },



];

function getTabs() {
  return presidents.map((president, index) => ({
    title: president.name,
    getContent: () => president.biography,
    /* Optional parameters */
    key: index,
    tabClassName: 'tab',
    panelClassName: 'panel',
  }));
}

// This site has 3 pages, all of which are rendered
// dynamically in the browser (not server rendered).
//
// Although the page does not ever refresh, notice how
// React Router keeps the URL up to date as you navigate
// through the site. This preserves the browser history,
// making sure things like the back button and bookmarks
// work properly.

store.subscribe(() => {
  //debugger
  console.log(store.getState())
});

export default class App extends React.Component {

  constructor(props) {
    super(props);
    this.jp = React.createRef();
    this.state = {
      text: false,
      Result: [],
      counter:0
    }
    this.changeHandle = this.changeHandle.bind(this);

    this.EventHandler = this.EventHandler.bind(this);
    console.log("constructor");
  }

  changeHandle(event) {

    var inputString = event.target.value;
    this.state.List.map((element, index) => {
      // console.log(element);
      if (element.includes(inputString)) {
        this.state.Result.push(element)
        // console.log(element, index);
        //this.setState({ Result: element })
      }
      //this.state.InputState.push(InputState);
    })
    console.log("Result", this.state.Result);
  }



  EventHandler(event) {
    if (event.target.closest('.head_info_btn')) {
      this.setState({ text: true });
    } else {
      this.setState({ text: false });
    }

  }
  timer=() => {
    this.setState({counter: this.state.counter+1});
  }
  componentDidMount() {
    console.log("componentDidMount");
  }
  render() {
    console.log("render");
    return (
      <BrowserRouter>
        <Router history={history}>
          <div>

            <div className="wlc_header">
              <div className="wlc_logo_sec">
                <img src={logo} alt="Logo" />
              </div>
              <div className="wlc_main_tab">

                {/* <div className="WLC_home_return" onClick={this.timer}>Home {this.state.counter}</div> */}

                <ul className="wlc_top_menu">
                  <li>
                    <a href="#">Save Configuration</a>
                  </li>
                  <li>
                    <a href="#">Ping</a>
                  </li>
                  <li>
                    <a href="#">Logout</a>
                  </li>
                  <li>
                    <a href="#">Refresh</a>
                  </li>
                </ul>

                <ul className="wlc_main_menu">
                  <li>
                    <NavLink to="/monitor">MONITOR</NavLink>
                  </li>
                  <li>
                    <NavLink to="/about">WLANs</NavLink>
                  </li>
                  <li>
                    <NavLink to="/dashboard" >CONTROLLER</NavLink>
                  </li>
                  <li>
                    <Link to="/d">WIRELESS</Link>
                  </li>
                  <li>
                    <Link to="/dashbosdsard">SECURITY</Link>
                  </li>
                  <li>
                    <Link to="/dashsssboard">MANAGEMENT</Link>
                  </li>
                  <li>
                    <Link to="/dashbsssddoard">COMMANDS</Link>
                  </li>
                  <li>
                    <Link to="/dashdddboard">HELP</Link>
                  </li>
                  <li>
                    <Link to="/dfashboard">FEEDBACK</Link>
                  </li>
                </ul>

              </div>
            </div>

            <div className="wlc_routing_page">
            <div className="tab_header">
            <Tabs selectedTabKey={1}  items={getTabs()} showMore={true} transformWidth="400"/>
            </div>
              {/* <Switch>
                <Route exact path="/monitor">
                  <Home time={this.state.counter}/>
                </Route>
                <Route path="/about">
                  <About />
                </Route>
              </Switch> */}
            </div>

            <symbol id="Config-Scen-Icon" width="32px" height="32px" viewBox="0 0 32 32"  >
              <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                  <rect id="Rectangle" fill="#FFFFFF" x="0" y="0" width="32" height="32"></rect>
                  <g id="desktop_mac-24px-(2)">
                      <polygon id="Path" points="0 0 24 0 24 24 0 24"></polygon>
                      <path d="M25.8181818,4 L6.18181818,4 C4.98181818,4 4,5.08 4,6.4 L4,20.8 C4,22.12 4.98181818,23.2 6.18181818,23.2 L13.8181818,23.2 L11.6363636,26.8 L11.6363636,28 L20.3636364,28 L20.3636364,26.8 L18.1818182,23.2 L25.8181818,23.2 C27.0181818,23.2 28,22.12 28,20.8 L28,6.4 C28,5.08 27.0181818,4 25.8181818,4 Z M25.8181818,18.4 L6.18181818,18.4 L6.18181818,6.4 L25.8181818,6.4 L25.8181818,18.4 Z" id="Shape" fill="#7B7F7F" fill-rule="nonzero"></path>
                  </g>
                  <g id="settings-24px" transform="translate(7.000000, 4.000000)">
                      <polygon id="Path" points="0 0 10 0 10 10 0 10"></polygon>
                      <path d="M11.9407795,8.940625 C11.9600556,8.8 11.9696936,8.6546875 11.9696936,8.5 C11.9696936,8.35 11.9600556,8.2 11.9359605,8.059375 L12.9142213,7.31875 C13.0009636,7.253125 13.0250587,7.1265625 12.9720495,7.0328125 L12.0467979,5.4765625 C11.9889697,5.3734375 11.8684942,5.340625 11.7624758,5.3734375 L10.6107303,5.8234375 C10.3697793,5.6453125 10.1143713,5.4953125 9.83004921,5.3828125 L9.65656453,4.1921875 C9.63728846,4.0796875 9.54090808,4 9.42525163,4 L7.57474837,4 C7.45909192,4 7.36753056,4.0796875 7.34825448,4.1921875 L7.1747698,5.3828125 C6.89044769,5.4953125 6.63022067,5.65 6.39408874,5.8234375 L5.24234323,5.3734375 C5.13632481,5.3359375 5.01584934,5.3734375 4.95802111,5.4765625 L4.03758851,7.0328125 C3.97976028,7.13125 3.99903636,7.253125 4.09541673,7.31875 L5.07367757,8.059375 C5.04958247,8.2 5.0303064,8.3546875 5.0303064,8.5 C5.0303064,8.6453125 5.03994444,8.8 5.06403953,8.940625 L4.0857787,9.68125 C3.99903636,9.746875 3.97494126,9.8734375 4.02795047,9.9671875 L4.9532021,11.5234375 C5.01103032,11.6265625 5.13150579,11.659375 5.23752421,11.6265625 L6.38926973,11.1765625 C6.63022067,11.3546875 6.88562867,11.5046875 7.16995079,11.6171875 L7.34343547,12.8078125 C7.36753056,12.9203125 7.45909192,13 7.57474837,13 L9.42525163,13 C9.54090808,13 9.63728846,12.9203125 9.65174552,12.8078125 L9.8252302,11.6171875 C10.1095523,11.5046875 10.3697793,11.3546875 10.6059113,11.1765625 L11.7576568,11.6265625 C11.8636752,11.6640625 11.9841507,11.6265625 12.0419789,11.5234375 L12.9672305,9.9671875 C13.0250587,9.8640625 13.0009636,9.746875 12.9094023,9.68125 L11.9407795,8.940625 Z M8.5,10.1875 C7.54583426,10.1875 6.7651532,9.428125 6.7651532,8.5 C6.7651532,7.571875 7.54583426,6.8125 8.5,6.8125 C9.45416574,6.8125 10.2348468,7.571875 10.2348468,8.5 C10.2348468,9.428125 9.45416574,10.1875 8.5,10.1875 Z" id="Shape" fill="#6A7070" fill-rule="nonzero"></path>
                  </g>
              </g>
            </symbol>

            <symbol id="Skill-Builders-Icon" width="32px" height="32px" viewBox="0 0 32 32" >
                <g  stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                    <rect id="Rectangle" fill="#FFFFFF" x="0" y="0" width="32" height="32"></rect>
                    <g id="desktop-18" transform="translate(4.000000, 7.000000)">
                        <rect id="grid-18" x="0" y="0" width="23.6587678" height="19"></rect>
                        <path d="M23.0965155,15 L14.5178097,15 L14.5178097,15.6666667 C14.5178097,16.0666667 14.2538496,16.3333333 13.8579093,16.3333333 L9.89850664,16.3333333 C9.50256637,16.3333333 9.2386062,16.0666667 9.2386062,15.6666667 L9.2386062,15 L0.659900443,15 C0.263960177,15 0,15.2666667 0,15.6666667 L0,17.4 C0,18.3333333 0.791880531,19 1.58376106,19 L22.0406748,19 C22.9645354,19 23.6244358,18.2 23.6244358,17.4 L23.6244358,15.6666667 C23.7564159,15.2666667 23.4924558,15 23.0965155,15 L23.0965155,15 Z" id="icon" fill="#6A7070"></path>
                        <path d="M20.3728278,0.333333333 C21.4243286,0.333333333 22.3443918,1.26666667 22.3443918,2.33333333 L22.3443918,2.33333333 L22.3443918,13 C22.3443918,13.4 22.0815166,13.6666667 21.6872038,13.6666667 L21.6872038,13.6666667 L1.97156398,13.6666667 C1.57725118,13.6666667 1.31437599,13.4 1.31437599,13 L1.31437599,13 L1.31437599,2.33333333 C1.31437599,1.26666667 2.23443918,0.333333333 3.28593997,0.333333333 L3.28593997,0.333333333 Z" id="icon" fill="#6A7070"></path>
                    </g>
                </g>
            </symbol>

            <symbol id="Subnet-Exerc-Icon" width="32px" height="32px" viewBox="0 0 32 32" >
                <g  stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                    <rect id="Rectangle" fill="#FFFFFF" x="0" y="0" width="32" height="32"></rect>
                    <image id="Screenshot-2020-05-15-at-9.21.19-PM" x="0" y="0" width="35.6984925" height="32" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAN4AAADHCAYAAAB2vu3kAAAKuWlDQ1BJQ0MgUHJvZmlsZQAASImVlwdUk8kWx+f7vnQSWkIEpITeBOlVSuihCNLBRkhCEkoMCUHFrogruBZERLCiSxEF1wLIWhALFhZBBewbZFFR18WCoqi8D3mE3ffOe++8e85kfufmzr135szk/AMAeYQtFmfAqgBkirIlUUG+jITEJAb+dwABGBCBM0DYHKmYGRkZBlCbnP9uH3rQaNRuW4/n+vfv/6upcXlSDgBQJMopXCknE+WT6JBzxJJsAJBi1G+0OFs8zk0o0yRogyi3jzN/guXjnDLB77/HxET5AYAhAEAgs9kSPgBkGupn5HD4aB6yI8q2Iq5QhDIXZS+OgI3O5EMoz8jMXDTOnSibp/wlD/9vOVMUOdlsvoIn9vLdCP5CqTiDvfT/PI7/bZkZsskapuggCyTBUeP10DO7m74oVMGilNkRkyzkTvQ0zgJZcOwkc6R+SZPMZfuHKtZmzA6b5FRhIEuRJ5sVM8k8aUD0JEsWRSlqpUr8mJPMlkzVlaXHKvwCHkuRP1cQEz/JOcK42ZMsTY8OnYrxU/glsihF/zxRkO9U3UDF3jOlf9mvkKVYmy2ICVbsnT3VP0/EnMopTVD0xuX5B0zFxCrixdm+ilrijEhFPC8jSOGX5kQr1majF3JqbaTiDNPYIZGTDIQgHLABJ5u3JHu8eb9F4qUSIV+QzWCir4rHYIk4NjMY9rb2tgCMv9GJK/CO/v3tQfTrU76sFgDcClAnf8rHNgLg9FMAqB+mfEZv0euzFYCznRyZJGfChxn/wAISUAE0oAX0gBEwB9bAHv0l8AA+IACEgAgQAxLBAsABApAJJGAxWA7WgHxQCLaCHaAM7AMHQTU4Co6DRnAGXABXwA3QCbrBAyAHA+AlGAIfwCgEQXiIAlEhLUgfMoGsIHvIFfKCAqAwKApKhJIhPiSCZNByaB1UCBVBZdABqAb6GToNXYCuQV3QPagPGoTeQp9hBCbDNFgXNoVnwq4wEw6FY+D5MB/OgnPhPHgzXApXwEfgBvgCfAPuhuXwS3gYAYgSQkcMEGvEFfFDIpAkJBWRICuRAqQEqUDqkGakDbmNyJFXyCcMDkPFMDDWGA9MMCYWw8FkYVZiNmHKMNWYBswlzG1MH2YI8w1LwepgrbDuWBY2AcvHLsbmY0uwldhT2MvYbuwA9gMOh6PjzHAuuGBcIi4Ntwy3CbcHV49rwXXh+nHDeDxeC2+F98RH4Nn4bHw+fhf+CP48/hZ+AD9CUCLoE+wJgYQkgoiwllBCOEw4R7hFeEYYJaoSTYjuxAgil7iUuIV4iNhMvEkcII6S1EhmJE9SDCmNtIZUSqojXSY9JL1TUlIyVHJTmqMkVFqtVKp0TOmqUp/SJ7I62ZLsR55HlpE3k6vILeR75HcUCsWU4kNJomRTNlNqKBcpjykjylRlG2WWMld5lXK5coPyLeXXKkQVExWmygKVXJUSlRMqN1VeqRJVTVX9VNmqK1XLVU+r9qoOq1HV7NQi1DLVNqkdVrum9lwdr26qHqDOVc9TP6h+Ub2filCNqH5UDnUd9RD1MnWAhqOZ0Vi0NFoh7Sitgzakoa7hqBGnsUSjXOOshpyO0E3pLHoGfQv9OL2H/nma7jTmNN60jdPqpt2a9lFzuqaPJk+zQLNes1vzsxZDK0ArXWubVqPWI22MtqX2HO3F2nu1L2u/mk6b7jGdM71g+vHp93VgHUudKJ1lOgd12nWGdfV0g3TFurt0L+q+0qPr+eil6RXrndMb1Kfqe+kL9Yv1z+u/YGgwmIwMRinjEmPIQMcg2EBmcMCgw2DU0Mww1nCtYb3hIyOSkatRqlGxUavRkLG+cbjxcuNa4/smRBNXE4HJTpM2k4+mZqbxphtMG02fm2mascxyzWrNHppTzL3Ns8wrzO9Y4CxcLdIt9lh0WsKWTpYCy3LLm1awlbOV0GqPVdcM7Ay3GaIZFTN6rcnWTOsc61rrPhu6TZjNWptGm9czjWcmzdw2s23mN1sn2wzbQ7YP7NTtQuzW2jXbvbW3tOfYl9vfcaA4BDqscmhyeONo5chz3Ot414nqFO60wanV6auzi7PEuc550MXYJdllt0uvK8010nWT61U3rJuv2yq3M26f3J3ds92Pu//pYe2R7nHY4/kss1m8WYdm9XsaerI9D3jKvRheyV77veTeBt5s7wrvJz5GPlyfSp9nTAtmGvMI87Wvra/E95TvRz93vxV+Lf6If5B/gX9HgHpAbEBZwONAw0B+YG3gUJBT0LKglmBscGjwtuBeli6Lw6phDYW4hKwIuRRKDo0OLQt9EmYZJglrDofDQ8K3hz+cbTJbNLsxAkSwIrZHPIo0i8yK/GUObk7knPI5T6PsopZHtUVToxdGH47+EOMbsyXmQax5rCy2NU4lbl5cTdzHeP/4onh5wsyEFQk3ErUThYlNSfikuKTKpOG5AXN3zB2Y5zQvf17PfLP5S+ZfW6C9IGPB2YUqC9kLTyRjk+OTDyd/YUewK9jDKayU3SlDHD/OTs5Lrg+3mDvI8+QV8Z6leqYWpT7ne/K38wcF3oISwSuhn7BM+CYtOG1f2sf0iPSq9LGM+Iz6TEJmcuZpkbooXXRpkd6iJYu6xFbifLE8yz1rR9aQJFRSKYWk86VN2TRUDLXLzGXrZX05XjnlOSOL4xafWKK2RLSkfanl0o1Ln+UG5v60DLOMs6x1ucHyNcv7VjBXHFgJrUxZ2brKaFXeqoHVQaur15DWpK/5da3t2qK179fFr2vO081bnde/Pmh9bb5yviS/d4PHhn0/YH4Q/tCx0WHjro3fCrgF1wttC0sKv2zibLr+o92PpT+ObU7d3LHFecverbitoq0927y3VRepFeUW9W8P395QzCguKH6/Y+GOayWOJft2knbKdspLw0qbdhnv2rrrS5mgrLvct7x+t87ujbs/7uHuubXXZ2/dPt19hfs+7xfuv3sg6EBDhWlFyUHcwZyDTw/FHWr7yfWnmkrtysLKr1WiKnl1VPWlGpeamsM6h7fUwrWy2sEj8450HvU/2lRnXXegnl5feAwckx178XPyzz3HQ4+3nnA9UXfS5OTuU9RTBQ1Qw9KGoUZBo7wpsanrdMjp1maP5lO/2PxSdcbgTPlZjbNbzpHO5Z0bO597frhF3PLqAv9Cf+vC1gcXEy7euTTnUsfl0MtXrwReudjGbDt/1fPqmWvu105fd73eeMP5RkO7U/upX51+PdXh3NFw0+VmU6dbZ3PXrK5zt7xvXbjtf/vKHdadG92zu7t6Ynvu9s7rld/l3n1+L+Pem/s590cfrH6IfVjwSPVRyWOdxxW/WfxWL3eWn+3z72t/Ev3kQT+n/+Xv0t+/DOQ9pTwteab/rOa5/fMzg4GDnS/mvhh4KX45+ir/D7U/dr82f33yT58/24cShgbeSN6Mvd30Tutd1XvH963DkcOPP2R+GP1YMKI1Uv3J9VPb5/jPz0YXf8F/Kf1q8bX5W+i3h2OZY2NitoT9XQog6IBTUwF4WwUAJRHVDqgmJs2d0NDfDZrQ/d8J/Cee0NnfzRmAKh8AYlcDEIZqlL3oMEGZjM7jMijGB8AODorxT5OmOthP5CKjahI7Mjb2ThcAfDMAXyVjY6N7xsa+oroduQdAS9aEdh83HPqPZr/6OLXrLXsN/sX+Adh9DxqE3FPkAAALmUlEQVR4Ae3d/29V9R3H8Xe1ZYIwCoWCFnTREkcm0MIUkOHExfgFsqWGIsGFH5ZosvnL/gF/2o/+YLNQmehIZBtDzAZCQyRsYDRpiIBUcIhWBBzypWi/8qVfQt09HTc91dt7bu89n/fn8zn3eZLmnt5zzuf9+Tw+50XPPZf2lnybWoQFAQRUBW5RrUYxBBAYEiB4nAgIWBAgeBbQKYkAweMcQMCCAMGzgE5JBAge5wACFgQIngV0SiJA8DgHELAgQPAsoFMSAYLHOYCABQGCZwGdkggQPM4BBCwIEDwL6JREgOBxDiBgQYDgWUCnJAIEj3MAAQsCBM8COiURIHicAwhYECB4FtApiUCpawQnTp6UL06fls7OTunu6ZH+/n7XuqjWn1lVVbK6rk6tHoX0BJwIXkcqZLv37JEPW1pkYGBAb/RUQsCSgPXg7dy9W/bt329p+JRFwI6AteBdu3ZNNr72mnxx5oydkVMVAYsCVoIXhO6lhgZpu3zZ4tApjYA9AfW7mjdu3JBXUj/pCJ29SaeyfQH1n3jB67nTCbm8vGPmTHlsxYrIWWxvb5emvXsj92OH4hFQDV5Xd7e8s29fonR/MG5cosbDYHQEVC81d+zaxdsFOvNKFccF1IIX3FA5dOSI4xx0DwEdAbXgfdraGj0iPrgo2og9EiGgFrzzFy5Eg5WURO/DHggkQEAteMGNFRYEEPi/gF7wurowRwCBmwJqwevr6wMdAQS0g4c4AggMC6i+gT5cNhlrHR0d8pdt25IxGEahKkDwCuDu5fK5AL3iPlTtNV5xMzN6BEYKELyRHnyHgIoAwVNhpggCIwUI3kgPvkNARYDgqTBTBIGRAk7f1aycPn1kbz3/jt+693wCY+y+08Fbt2aNzKmujnG49ppqaGzkz13Y43euMpeazk0JHSoGAYJXDLPMGJ0TIHjOTQkdKgYBglcMs8wYnRNw+ubKaFqu3x1M2t3Y0eaB5/MX8DJ4W7dvl9bPP89/1AaP/P0LLwjBMwickKa51EzIRDIMvwQInl/zRW8TIkDwEjKRDMMvAYLn13zR24QIELyETCTD8EuA4Pk1X/Q2IQJevp1QdeedEnyxIOCrgJfBq6+r89WbfiMwJMClJicCAhYECJ4FdEoiQPA4BxCwIEDwLKBTEgGnb66cP39Bgi8WBJIm4HTwtu/4Z9K8GQ8CQwJcanIiIGBBgOBZQKckAgSPcwABCwIEzwI6JREgeJwDCFgQIHgW0CmJgNNvJ/zu+ecTM0P79u939g80JQbZo4E4HbxxZWWJ+eyEIHgsCKQFuNRMS/CIgKIAwVPEphQCaQGCl5bgEQFFAYKniE0pBNICTt9cSXfyu4+vbNr03aec+f6xRx9NzA0hZ1AT2BEvg9c/MKBya/6OmTPlrlmzpaJiqkwYP15uKYm+QKiclvnjo1csf1hq580f0ylUPnnymPZnZ38EvAyeSd6KigpZtmSJLKqpkWnTpsVWasH8ebG1RUP+CxC8m3NYWloqv1y5Un7xyCP+zyojcF6A4KWmaE51taxbs4aP13L+dE1OB4s+eItqa+U369cnZ0YZiRcCRR28+fffHxm69o4O+e+5c/JNe7tcv37di0n1vZPBjaypU6fKXbNny5Tyct+Hk7H/RRu84MbJ+mefzYhy9epVeb+5WT44fFgutbVl3IcndQRmzpghix94QJYvWybjb7tNp6hCFS+DF3zcsaml9dQp+dPrr0tvb6+pErQ7BoGLly7J201N8u8DB+S3zz0nP7r77jEc7e6u0W9Mudv32Hv2YUuLNGzYQOhily28wSupq5CXGhrkxMmThTfmQAsE7+YkBBP65zfecGBK6EI2gcZXX5UzZ89m28WLbQQvNU19fX3ytzff9GLC6KTIlq1bZXBw0GsKgpeavoOHDklnZ6fXE1lMnQ9ueB37+GOvh0zwUtN39KOPvJ7EYux8y7FjXg/b6buaDY2NseP+4cUXh94jCjd88eLF8LeseyBw9ssvPejl6F10Onijdzv/LT/M8D/+e65cyanBpx5/PKf92KkwgT1790Y20Hb5cuQ+Lu9QdMErvfXWvOdj5RNP5H0sB+YukEvwcm/NzT15jefmvNCrhAsQvIRPMMNzU4DguTkv9CrhAgQv4RPM8NwUcPrmyk/mznVTjV4hUKCA08HjL3YVOLsc7qwAl5rOTg0dS7IAwUvy7DI2ZwUInrNTQ8eSLEDwkjy7jM1ZAadvroym9p9PPhltU+Tz3CmNJGIHBQEvg1fIp6s2vvyyAislEMguwKVmdh+2ImBEgOAZYaVRBLILELzsPmxFwIgAwTPCSqMIZBcgeNl92IqAEQGCZ4SVRhHILuDl2wnBJ6uO9dNVszOwFQFdAS+D9/OHl+sqUQ2BmAW41IwZlOYQyEWA4OWixD4IxCxA8GIGpTkEchEgeLkosQ8CMQs4fXOl5fhxCb7iXOrr6uJsjrYQyEvA6eC9+957eQ0q20EEL5sO27QEuNTUkqYOAiEBghfCYBUBLQGCpyVNHQRCAgQvhMEqAloCBE9LmjoIhAQIXgiDVQS0BAieljR1EAgJELwQBqsIaAkQPC1p6iAQEiB4IQxWEdASIHha0tRBICRA8EIYrCKgJUDwtKSpg0BIgOCFMFhFQEuA4GlJUweBkADBC2GwioCWAMHTkqYOAiEBtd9AX/LggzKnujpUmlUEildANXi+Mzds2OD7EOi/IwJqwXNkvAV1o/XUqYKO52AE0gK8xktL8IiAogDBU8SmFAJpAYKXluARAUUBgqeITSkE0gIELy3BIwKKAgRPEZtSCKQFCF5agkcEFAUIniI2pRBICxC8lMSU8vK0B4+eCEydMsWTnmbuJsFLuVRVVWXW4VlnBWZ5PmcEL3Vq1cyb5+wJRscyCyysqcm8wZNnCV5qon66cCGXm56csEE3Z1RWSu2CBR71+PtdJXgpk7KyMvn12rXf1+EZJwXWPfOMlJb6/f/7Cd7NU+vH990nq5580skTjU4NC9Q//bRU33PP8BOerpV8m1o87buRbjcfPCj/2LlTevv6jLRPo/kJTJgwQdauXi2Lamvza8Cxowhehgnp6u4eCt+Ro0czbOUpTYGSkhJZunix/GrVKpl4++2apY3WInhZeLu6uuT4iRMSPLq09PT0yPvNzbF2aflDD8mkSZNibbPQxiqnT5e5qZcAEydOLLQp5473+xWqYc7JkyfLz5YuNVxl7M3/cePGsR8UcUTb11/L2vr6iL3YHJcAN1fiklRq518HDsinn30We7WgzaBtFh0BgqfjHEuVc199JW83NcXSVqZGgraDGizmBQieeeNYKvT398umzZtlcHAwlvYyNRK0HdQIarGYFSB4Zn1ja/3vb70l37S3x9beaA0FNYJaLGYFCJ5Z31haD97W+ODw4VjayqWRoBZvpeQilf8+BC9/O5Ujg59Af922TaVWuEhQU+MnbLhmMa0TPIdn2+ZrLo3XlA7TG+8awTNOnH8B23cZTd9FzV/G/yMJnqNz6Mr7aqbeN3SUXa1bBE+NOvdCV65elc1btuR+gOE9g74EfWKJT4DgxWcZW0uuneiu/UMQG7TFhgieRfxMpV29tHPl0jeTmY/PETzHZm3Hrl2O9Wi4Oy73bbiXfqwRPD/miV4mTIDgJWxCGY4fAgTPj3milwkT4BdhHZvQOffe61iP6I4JAf70gwlV2kQgQoBLzQggNiNgQoDgmVClTQQiBAheBBCbETAhQPBMqNImAhECBC8CiM0ImBAgeCZUaROBCAGCFwHEZgRMCBA8E6q0iUCEAMGLAGIzAiYECJ4JVdpEIEKA4EUAsRkBEwIEz4QqbSIQIUDwIoDYjIAJAYJnQpU2EYgQIHgRQGxGwIQAwTOhSpsIRAgQvAggNiNgQoDgmVClTQQiBAheBBCbETAhQPBMqNImAhECBC8CiM0ImBAgeCZUaROBCAGCFwHEZgRMCPwPEfPxXqBXNTQAAAAASUVORK5CYII="></image>
                </g>
            </symbol>

            <symbol id="Troubleshoot-Scen-Icon"  width="32px" height="32px" viewBox="0 0 32 32" version="1.1">
                <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                    <rect id="Rectangle" fill="#FFFFFF" x="0" y="0" width="32" height="32"></rect>
                    <g id="desktop_mac-24px-(2)">
                        <polygon id="Path" points="0 0 24 0 24 24 0 24"></polygon>
                        <path d="M25.8181818,4 L6.18181818,4 C4.98181818,4 4,5.08 4,6.4 L4,20.8 C4,22.12 4.98181818,23.2 6.18181818,23.2 L13.8181818,23.2 L11.6363636,26.8 L11.6363636,28 L20.3636364,28 L20.3636364,26.8 L18.1818182,23.2 L25.8181818,23.2 C27.0181818,23.2 28,22.12 28,20.8 L28,6.4 C28,5.08 27.0181818,4 25.8181818,4 Z M25.8181818,18.4 L6.18181818,18.4 L6.18181818,6.4 L25.8181818,6.4 L25.8181818,18.4 Z" id="Shape" fill="#7B7F7F" fill-rule="nonzero"></path>
                        <g id="warning-24px" transform="translate(4.000000, 3.000000)">
                            <polygon id="Path" points="0 0 24 0 24 24 0 24"></polygon>
                            <path d="M8,13 L16,13 L12,5 L8,13 Z M12.3636364,11.7368421 L11.6363636,11.7368421 L11.6363636,10.8947368 L12.3636364,10.8947368 L12.3636364,11.7368421 Z M12.3636364,10.0526316 L11.6363636,10.0526316 L11.6363636,8.36842105 L12.3636364,8.36842105 L12.3636364,10.0526316 Z" id="Shape" fill="#7B7F7F" fill-rule="nonzero"></path>
                        </g>
                    </g>
                    <g id="settings-24px" transform="translate(7.000000, 4.000000)">
                        <polygon id="Path" points="0 0 10 0 10 10 0 10"></polygon>
                    </g>
                </g>
            </symbol>


          </div>
        </Router>
      </BrowserRouter>





    );
  }
}

// You can think of these components as "pages"
// in your app.




