import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import './index.css';


function One() {
  return (
    <div className="test">
        <h1>JAYAPRAKASH</h1>
    </div>
  )
}


function Two() {
  return (
    <div className="test">
        <h1>Ibrahimsha</h1>
    </div>
  )
}



ReactDOM.render(<App/>,document.getElementById('root')
);
