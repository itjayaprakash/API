import React from 'react';
import * as  redux from 'redux';
//Action

export const COUNTER_INCREMENT = 'counter/increment' ;
export const COUNTER_DECREMENT = 'counter/decrement' ;

const InitialState = {
    Value:false
}

//Reducer
const Reducer = (state = InitialState, action) => {
    switch(action.type) {
        case COUNTER_INCREMENT : {
            return {state : true}; console.log(state,"STATE Chganged INC") ;
        }
        case COUNTER_DECREMENT : {
            return {state : false}; console.log(state,"STATE Chganged INC") 
        }
    }
}

//Store
const store = redux.createStore(Reducer);


export default store;