import React from 'react';

const Mycomponent = ImplementComponent => {
    class NewComponent extends React.Component{
         handleClick(e) {
            console.log('The link was clicked.');
          }
        render(){
            return <ImplementComponent name="Jayaprakash" newFunc={this.handleClick}/>
        }
    }
    return NewComponent
}

export default Mycomponent;