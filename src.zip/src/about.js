import React, { Component, Fragment } from 'react';
export default class About extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            WalletTracker: [],
            date: '',
            description: '',
            income: '',
            expense: ''
        }
        this.FormSubmission = this.FormSubmission.bind(this);
        this.HandleChange = this.HandleChange.bind(this);
    }

    HandleChange(event) {
        var stateName = event.target.name;
        console.log(stateName);
        this.setState({ [event.target.name]: event.target.value })
    }

    FormSubmission(event) {
        var EachRow = { date: this.state.date, description: this.state.description, income: this.state.income, expense: this.state.expense };
        this.state.WalletTracker.push(EachRow);
    }

    render() {
        console.log("JP", this.state.WalletTracker);
        return (
            <Fragment>

                <div className="wlc_sidebar">
                    <h1>WLAN</h1>
                    <ul>
                        <li>
                            <a href="#">Summary</a>
                        </li>
                        <li>
                            <a href="#">Access Points</a>
                        </li>
                        <li>
                            <a href="#">Cisco CleanAir</a>
                        </li>
                        <li>
                            <a href="#">Statistics</a>
                        </li>
                        <li>
                            <a href="#">CDP</a>
                        </li>
                        <li>
                            <a href="#">CDP</a>
                        </li>
                    </ul>
                </div>

                <div className="wlc_main_sec">
                    <h1>WLAN</h1>
                    <div className="Form_Control">
                        <div>
                            <input type="date" name="date" placeholder="Date" onChange={this.HandleChange} />
                            <input type="text" name="description" placeholder="Description" onChange={this.HandleChange} />
                            <input type="text" name="income" placeholder="Income" onChange={this.HandleChange} />
                            <input type="text" name="expense" placeholder="Expence" onChange={this.HandleChange} />
                            <button type="submit" name="Submit" onClick={this.FormSubmission}>Submit</button>
                        </div>
                    </div>
                    <div className="List_Control Table_Widget">
                        <table>
                            <thead>
                                <tr>
                                    <th>
                                        S.No
                                        </th>
                                    <th>
                                        date
                                        </th>
                                    <th>
                                        description
                                        </th>
                                    <th>
                                        income
                                        </th>
                                    <th>
                                        expense
                                        </th>
                                </tr>
                            </thead>
                            <tbody>
                                {this.state.WalletTracker.map((data, index) =>
                                    <tr>
                                        <td>{index}</td>
                                        <td>{data.date}</td>
                                        <td>{data.description}</td>
                                        <td>{data.income}</td>
                                        <td>{data.expense}</td>
                                    </tr>)
                                }
                            </tbody>
                        </table>
                    </div>
                </div>

            </Fragment>
        )
    }
}