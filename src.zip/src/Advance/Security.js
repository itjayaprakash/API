import React, { Component, Fragment } from 'react';

import {Button,Icon,RadioCheckGroup,TextInput} from '@pearson-components/elements-sdk/build/dist.elements-sdk';
import '@pearson-components/elements-sdk/build/css/elements.css';
import GreenSignal from './green.gif';
import RedSignal from './red.gif';
import RightArrow from './arrow_right.gif';
export default class Security extends Component {
    render() {
        return (
            <Fragment>

                <div className="wlc_sidebar">
                    <h1>Security</h1>
                    <ul>
                        <li>
                            <a href="#">AAA</a>
                            <ul className="wlc_menuitem">
                                <li><a href="#">General</a></li>
                                <li><a href="#"> RADIUS</a>
                                    <ul className="Wlc_menuitem2"><li><a href="#">Authentication</a></li>
                                        <li><a href="#">Accounting</a></li>
                                        <li><a href="#">Fallback</a></li>
                                        <li><a href="#">DNS</a></li>
                                        <li><a href="#">Downloaded AVP</a></li></ul></li>
                                <li><a href="#">TACACS+</a></li>
                                <li><a href="#">LDAP</a></li>
                                <li><a href="#">Local Net Users</a></li>
                                <li><a href="#">MAC Filtering</a></li>
                                <li><a href="#">Disabled Clients</a></li>
                                <li><a href="#">User login Policies</a></li>
                                <li><a href="#">AP Policies</a></li>
                                <li><a href="#">Password Policies</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#"><span className="wlc_menu_rt_arrow"> <img src={RightArrow} /></span> Local EAP</a>
                        </li>
                        <li>
                            <a href="#"> Advanced EAP</a>
                        </li>
                        <li>
                            <a href="#"><span className="wlc_menu_rt_arrow"> <img src={RightArrow} /></span> Priority Order</a>
                        </li>
                        <li>
                            <a href="#"><span className="wlc_menu_rt_arrow"> <img src={RightArrow} /></span> Certificate</a>
                        </li>
                        <li>
                            <a href="#"><span className="wlc_menu_rt_arrow"> <img src={RightArrow} /></span> Access Control lists</a>
                        </li>
                        {/* <li>
                            <a href="#">Clients</a>
                        </li>
                        <li>
                            <a href="#">Sleeping Clients</a>
                        </li>
                        <li>
                            <a href="#">Multicast</a>
                        </li> */}
                        <li>
                            <a href="#"><span className="wlc_menu_rt_arrow"> <img src={RightArrow} /></span> Wireless Protection Policies</a>
                        </li>
                        <li>
                            <a href="#"><span className="wlc_menu_rt_arrow"> <img src={RightArrow} /></span> Web Auth</a>
                        </li>
                        <li>
                            <a href="#"><span className="wlc_menu_rt_arrow"> <img src={RightArrow} /></span> TrustSec</a>
                        </li>
                        <li>
                            <a href="#">Local Policies</a>
                        </li>
                        <li>
                            <a href="#"><span className="wlc_menu_rt_arrow"> <img src={RightArrow} /></span> OpenDNS</a>
                        </li>
                        <li>
                            <a href="#"><span className="wlc_menu_rt_arrow"> <img src={RightArrow} /></span> Advanced</a>
                        </li>
                    </ul>
                </div>

                <div className="wlc_main_sec">

                    <span className="Security_button"><h2 className="head_title_blur">RADIUS Authentication Servers</h2>
                    {/* <Button>Apply</Button>
                    <Button>New</Button> */}
                    </span>
                    <div className="Security_Table_Widget">
                        {/* <h1 className="wlc_widget_title">Controller Summary</h1> */}
                        <table>
                            <tr>
                                <td>
                                    Auth Called Station ID type
                                </td>
                                <td>
                                    <select id="" name="">
                                        <option value="AP MAC Address:SSID">AP MAC Address:SSID</option>
                                        <option value="AP MAC Address:SSID1">AP MAC Address:SSID1</option>
                                        <option value="AP MAC Address:SSID2">AP MAC Address:SSID2</option>
                                        <option value="AP MAC Address:SSID3">AP MAC Address:SSID3</option>
                                    </select>
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    Use AES Key Wrap
                                </td>
                                <td className="Security_checkbox">
                                <RadioCheckGroup inputType="checkbox" id="check1"  options={[{value: 0, label: "(Designed for FIPS customers and requires a key wrap compliant RADIUS server)", checked: true}]} changeHandler={() => {}} ></RadioCheckGroup>

                                </td>
                            </tr>

                            <tr>
                                <td>
                                    MAC Delimiter
                                </td>
                                <td>
                                <select id="" name="">
                                        <option value="Hyphen">Hyphen</option>
                                        {/* <option value="AP MAC Address:SSID1">AP MAC Address:SSID1</option>
                                        <option value="AP MAC Address:SSID2">AP MAC Address:SSID2</option>
                                        <option value="AP MAC Address:SSID3">AP MAC Address:SSID3</option> */}
                                    </select>
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    Framed MTU
                                </td>
                                <td className="security_text">
                                <TextInput id="a" inputState="default" changeHandler={() => {}} labelText="" placeholder="" infoMessage="This is an info message" value="1300" errorMessage="This is an error message" ></TextInput>


                                </td>
                            </tr>

                            
                        </table>
                    </div>

                    <div className="Table_Widget1">
                        
                        <table >
                            <thead>
                                <tr>
                                    <th>
                                        Network User
                                    </th>
                                    <th>
                                        Management
                                    </th>
                                    <th>
                                    Tunnel Proxy
                                    </th>
                                    <th>
                                        Server Index
                                    </th>
                                    <th>
                                       Server Address(Ipv4/Ipv6)
                                    </th>
                                    <th>
                                        Port
                                    </th>
                                    <th>
                                        IPSec
                                    </th>
                                    <th>
                                        Admin Status
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>

                    
                   
                </div>
            </Fragment>
        )
    }
}
