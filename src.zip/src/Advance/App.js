import React from "react";
import { BrowserRouter, Router, Route, NavLink, Switch, Redirect, Link } from 'react-router-dom';
import history from "./history";
import Home from './home';
import About from './about';
import logo from './cisco-logo-2007.gif';

import './App.css';
import store, { COUNTER_INCREMENT, COUNTER_DECREMENT } from './Store';




// This site has 3 pages, all of which are rendered
// dynamically in the browser (not server rendered).
//
// Although the page does not ever refresh, notice how
// React Router keeps the URL up to date as you navigate
// through the site. This preserves the browser history,
// making sure things like the back button and bookmarks
// work properly.

store.subscribe(() => {
  //debugger
  console.log(store.getState())
});

export default class App extends React.Component {

  constructor(props) {
    super(props);
    this.jp = React.createRef();
    this.state = {
      text: false,
      Result: []
    }
    this.changeHandle = this.changeHandle.bind(this);

    this.EventHandler = this.EventHandler.bind(this);
  }

  changeHandle(event) {

    var inputString = event.target.value;
    this.state.List.map((element, index) => {
      // console.log(element);
      if (element.includes(inputString)) {
        this.state.Result.push(element)
        // console.log(element, index);
        //this.setState({ Result: element })
      }
      //this.state.InputState.push(InputState);
    })
    console.log("Result", this.state.Result);
  }



  EventHandler(event) {
    if (event.target.closest('.head_info_btn')) {
      this.setState({ text: true });
    } else {
      this.setState({ text: false });
    }

  }

  render() {
    return (
      <BrowserRouter>
        <Router history={history}>
          <div>

            <div className="wlc_header">
              <div className="wlc_logo_sec">
                <img src={logo} alt="Logo" />
              </div>
              <div className="wlc_main_tab">

                <div className="WLC_home_return">Home</div>

                <ul className="wlc_top_menu">
                  <li>
                    <a href="#">Save Configuration</a>
                  </li>
                  <li>
                    <a href="#">Ping</a>
                  </li>
                  <li>
                    <a href="#">Logout</a>
                  </li>
                  <li>
                    <a href="#">Refresh</a>
                  </li>
                </ul>

                <ul className="wlc_main_menu">
                  <li>
                    <NavLink to="/monitor">MONITOR</NavLink>
                  </li>
                  <li>
                    <NavLink to="/about">WLANs</NavLink>
                  </li>
                  <li>
                    <NavLink to="/dashboard" >CONTROLLER</NavLink>
                  </li>
                  <li>
                    <Link to="/d">WIRELESS</Link>
                  </li>
                  <li>
                    <Link to="/dashbosdsard">SECURITY</Link>
                  </li>
                  <li>
                    <Link to="/dashsssboard">MANAGEMENT</Link>
                  </li>
                  <li>
                    <Link to="/dashbsssddoard">COMMANDS</Link>
                  </li>
                  <li>
                    <Link to="/dashdddboard">HELP</Link>
                  </li>
                  <li>
                    <Link to="/dfashboard">FEEDBACK</Link>
                  </li>
                </ul>

              </div>
            </div>

            <div className="wlc_routing_page">

           
            
              {/* <Switch>
                <Route exact path="/monitor">
                  <Home />
                </Route>
                <Route path="/about">
                  <About />
                </Route>
              </Switch> */}
            </div>

          </div>
        </Router>
      </BrowserRouter>
    );
  }
}

// You can think of these components as "pages"
// in your app.




