import React, { Component, Fragment } from 'react';
import Store, { COUNTER_INCREMENT, COUNTER_DECREMENT } from './Store';
import Network from './chassis5508.jpg';
import GreenSignal from './green.gif';
import RedSignal from './red.gif';
export default class Home extends Component {
    render() {
        return (
            <Fragment>
                
                <div className="wlc_sidebar">
                    <h1>Monitor JP</h1>
                    <h2></h2>
                    <ul>
                        <li>
                            <a href="#">Summary</a>
                        </li>
                        <li>
                            <a href="#">Access Points</a>
                        </li>
                        <li>
                            <a href="#">Cisco CleanAir</a>
                        </li>
                        <li>
                            <a href="#">Statistics</a>
                        </li>
                        <li>
                            <a href="#">CDP</a>
                        </li>
                        <li>
                            <a href="#">CDP</a>
                        </li>
                        <li>
                            <a href="#">Rogues</a>
                        </li>
                        <li>
                            <a href="#">Clients</a>
                        </li>
                        <li>
                            <a href="#">Sleeping Clients</a>
                        </li>
                        <li>
                            <a href="#">Multicast</a>
                        </li>
                    </ul>
                </div>

                <div className="wlc_main_sec">

                    <h2 className="head_title_blur">Summary</h2>

                    <div className="logo_sec">
                        <span>25 Access Points Supported</span>
                        <div><img src={Network} alt="LOGO" /></div>
                    </div>

                    <div className="Table_Widget">
                        <h1 className="wlc_widget_title">Controller Summary</h1>
                        <table>
                            <tr>
                                <td>
                                    Management IP Address	192.168.2.70 , ::/128
                                </td>
                                <td>
                                    192.168.2.70 , ::/128
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    Service Port IP Address
                                </td>
                                <td>
                                    192.168.1.70 , ::/128
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    Software Version
                                </td>
                                <td>
                                    8.5.151.0
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    Field Recovery Image Version
                                </td>
                                <td>
                                    7.6.101.1
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    System Name
                                </td>
                                <td>
                                    Simulator-WLC-5508
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    Up Time
                                </td>
                                <td>
                                    0 days, 0 hours, 18 minutes
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    Redundancy Mode
                                </td>

                                <td>
                                    Disabled
                                </td>
                            </tr>


                            <tr>
                                <td>
                                    Internal Temperature
                                </td>

                                <td>
                                    +36 C
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    802.11a Network State
                                </td>

                                <td>
                                    Enabled
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    802.11b/g Network State
                                </td>

                                <td>
                                    Enabled
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    Local Mobility Group
                                </td>

                                <td>
                                    RF_Group_Default
                                </td>
                            </tr>


                            <tr>
                                <td>
                                    CPU(s) Usage
                                </td>

                                <td>
                                    0%
                                </td>
                            </tr>


                            <tr>
                                <td>
                                    Individual CPU Usage
                                </td>
                                <td>
                                    0%/1%, 0%/0%, 0%/1%, 0%/0%, 0%/0%, 0%/0%, 0%/0%, 0%/0%, 0%/0%, 0%/0% 0%/1%, 0%/0%, 0%/1%, 0%/0%, 0%/0%, 0%/0%, 0%/0%, 0%/0%, 0%/0%, 0%/0%
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    Memory Usage
                                </td>
                                <td>
                                    38%
                                </td>
                            </tr>


                            <tr>
                                <td>
                                    Fan Status
                                </td>
                                <td>
                                    OK
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    Power Supply 1
                                </td>
                                <td>
                                    Present, OK
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    Power Supply 2
                                </td>
                                <td>
                                    Absent
                                </td>
                            </tr>






                        </table>
                    </div>

                    <div className="Table_Widget">
                        <h1 className="wlc_widget_title">Access Point Summary</h1>
                        <table width="400">
                            <thead>
                                <tr>
                                    <th>
                                    </th>
                                    <th>
                                        Total
                                    </th>
                                    <th>
                                        Up
                                    </th>
                                    <th>
                                        Down
                                    </th>
                                    <th>

                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        802.11a/n/ac Radios
                                    </td>
                                    <td>
                                        0
                                    </td>
                                    <td>
                                        <img src={GreenSignal} className="green_signal" />
                                        0
                                    </td>
                                    <td>
                                        <img src={RedSignal} className="red_signal" />
                                        0
                                    </td>

                                    <td>
                                        <a href="#" class="detail_lnk">Detail</a>
                                    </td>
                                </tr>

                                <tr>
                                    <td>
                                        802.11b/g/n Radios
                                    </td>
                                    <td>
                                        0
                                    </td>
                                    <td>
                                        <img src={GreenSignal} className="green_signal" />
                                        0
                                    </td>
                                    <td>
                                        <img src={RedSignal} className="red_signal" />
                                        0
                                    </td>

                                    <td>
                                        <a href="#" class="detail_lnk">Detail</a>
                                    </td>
                                </tr>

                                <tr>
                                    <td>
                                        Dual-Band Radios
                                    </td>
                                    <td>
                                        0
                                    </td>
                                    <td>
                                        <img src={GreenSignal} className="green_signal" />
                                        0
                                    </td>
                                    <td>
                                        <img src={RedSignal} className="red_signal" />
                                        0
                                    </td>
                                    <td>
                                        <a href="#" class="detail_lnk">Detail</a>
                                    </td>
                                </tr>

                                <tr>
                                    <td>
                                        All APs
                                    </td>
                                    <td>
                                        0
                                    </td>
                                    <td>
                                        <img src={GreenSignal} className="green_signal" />
                                        0
                                    </td>
                                    <td>
                                        <img src={RedSignal} className="red_signal" />
                                        0
                                    </td>

                                    <td>
                                        <a href="#" class="detail_lnk">Detail</a>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <div className="Table_Widget">
                        <h1 className="wlc_widget_title">Client Summary</h1>
                        <table width="400">
                            <tbody>
                                <tr>
                                    <td>
                                        Current Clients
                                    </td>
                                    <td>
                                        0
                                    </td>
                                    <td>
                                        <a href="#" class="detail_lnk">Detail</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        Excluded Clients
                                    </td>
                                    <td>
                                        0
                                    </td>
                                    <td>
                                        <a href="#" class="detail_lnk">Detail</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        Disabled Clients
                                    </td>
                                    <td>
                                        0
                                    </td>
                                    <td>
                                        <a href="#" class="detail_lnk">Detail</a>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <div className="Table_Widget">
                        <h1 className="wlc_widget_title">Rogue Summary </h1>
                        <table width="400">

                            <tbody>
                                <tr>
                                    <td>
                                        Active Rogue APs
                                    </td>
                                    <td>
                                        0
                                    </td>
                                    <td>
                                        <a href="#" class="detail_lnk">Detail</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        Active Rogue Clients
                                    </td>
                                    <td>
                                        0
                                    </td>
                                    <td>
                                        <a href="#" class="detail_lnk">Detail</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        Adhoc Rogues
                                    </td>
                                    <td>
                                        0
                                    </td>
                                    <td>
                                        <a href="#" class="detail_lnk">Detail</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        Rogues on Wired Network
                                    </td>
                                    <td>
                                        0
                                    </td>
                                    <td>
                                        <a href="#" class="detail_lnk">Detail</a>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <div className="Table_Widget">
                        <h1 className="wlc_widget_title">Session Timeout <input type="checkbox" name="vehicle1" value="Bike" /></h1>
                    </div>

                    <div className="Table_Widget">
                        <h1 className="wlc_widget_title">Top WLANs</h1>
                        <table width="400">
                           
                            <tbody>
                                <tr>
                                    <td>
                                    Profile Name
                                    </td>
                                    <td>
                                    # of Clients
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <div className="Table_Widget">
                        <h1 className="wlc_widget_title">Most Recent Traps</h1>
                        <table>
                            <tbody>
                                <tr>
                                    <td>AAA Authentication Failure for Client MAC: 00:00:00:01:00:00  UserName:Cisco  User Type: MGMT USER Reason: Authentication failed</td>
                                </tr>
                                <tr>
                                    <td>Link Up: Slot: 0 Port: 1  Admin Status: Enable Oper Status: Link Up retry-2</td>
                                </tr>
                                <tr>
                                    <td>Link Up: Slot: 0 Port: 1  Admin Status: Enable Oper Status: Link Up retry-1</td>
                                </tr>
                                <tr>
                                    <td>Interface: management IPv6 address status =REACHABLE, IPv6 Address =fe80::a66c:2aff:fe86:696f </td>
                                </tr>
                                <tr>
                                    <td>
                                        Cold Start:
                                        </td>
                                </tr>
                            </tbody>
                        </table>
                        <a href="#" className="view_all_btn">View All</a>
                    </div>

                    <div className="Table_Widget">
                        <h1 className="wlc_widget_title">Top Applications</h1>
                        <table className="styled_header">
                            <thead>
                                <tr>
                                    <th>Application Name</th>
                                    <th>Packet Count</th>
                                    <th>Byte Count</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                            </tbody>
                        </table>
                        <a href="#" className="view_all_btn">View All</a>
                    </div>

                    <div className="Table_Widget">
                        <h1 className="wlc_widget_title">Top Flex Applications</h1>
                        <table className="styled_header">
                            <thead>
                                <tr>
                                    <th>Application Name</th>
                                    <th>Packet Count</th>
                                    <th>Byte Count</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                            </tbody>
                        </table>
                        <a href="#" className="view_all_btn">View All</a>
                    </div>

                </div>
            </Fragment>
        )
    }
}
