import React, { Component } from 'react';
import {contextMenu} from './App';
const newObject =
 [ { id:1, name: "Jaya", age:26 }, { id:2, name: "rocky", age:27 }, { id:3, name: "naresh", age:27 }   ]



export default function Child(props){
       
        function handleClick(e) {
 
            console.log('The link was clicked.');
          }

         // const my = useContext(contextMenu);
        return(
            <div>
                <h1>JAAYAAPRAKASH {props.name} </h1>
                 { props.name ==25? <div> Reached 25 </div> : null}

                <ul>
                {
                    newObject.map((e) => <li>{e.id}, {e.name}, {e.age} </li>)
                }
                </ul>
                <div onClick={props.newmethod}> parent CLICK update</div>
                

               
            </div>
        )
}